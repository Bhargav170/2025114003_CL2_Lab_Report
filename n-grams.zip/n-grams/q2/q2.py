from collections import defaultdict

# Read the corpus
with open("./corpus.txt", "r") as file:
    sentences = file.read().split("\n")

# Store all unique words and their counts
all_words = []
word_count = defaultdict(int)

for sentence in sentences:
    for word in sentence.split():
        if word not in all_words:
            all_words.append(word)
        word_count[word] += 1

# Vocabulary size
V = len(all_words)

# Count bigrams
bigrams_count = defaultdict(int)
smoothed_probability = defaultdict(float)

for sentence in sentences:
    words = sentence.split()
    for i in range(len(words) - 1):
        bigrams_count[(words[i], words[i + 1])] += 1

# Print the results
print(f"{'Word 1':<12}{'Word 2':<12}| {'Count':<8}| Smoothed Probability")
print("-" * 60)

# First print bigrams with count > 0
for word1 in all_words:
    for word2 in all_words:
        count = bigrams_count[(word1, word2)]

        if count != 0:
            probability = (count + 1) / (word_count[word1] + V)
            smoothed_probability[(word1, word2)] = probability

            print(
                f"{word1:<12}{word2:<12}| {count:<8}| {probability:.5f}"
            )

# Then print bigrams with count = 0
for word1 in all_words:
    for word2 in all_words:
        count = bigrams_count[(word1, word2)]

        if count == 0:
            probability = (count + 1) / (word_count[word1] + V)
            smoothed_probability[(word1, word2)] = probability

            print(
                f"{word1:<12}{word2:<12}| {count:<8}| {probability:.5f}"
            )

# Write the results to a file
with open("./q2/output.txt", "w") as output:

    output.write(f"{'Word 1':<12}{'Word 2':<12}| {'Count':<8}| Smoothed Probability\n")
    output.write("-" * 60 + "\n")

    # First write bigrams with count > 0
    for word1 in all_words:
        for word2 in all_words:
            count = bigrams_count[(word1, word2)]

            if count != 0:
                probability = smoothed_probability[(word1, word2)]

                output.write(
                    f"{word1:<12}{word2:<12}| {count:<8}| {probability:.5f}\n"
                )

# Then write bigrams with count = 0
    for word1 in all_words:
        for word2 in all_words:
            count = bigrams_count[(word1, word2)]

            if count == 0:
                probability = smoothed_probability[(word1, word2)]

                output.write(
                    f"{word1:<12}{word2:<12}| {count:<8}| {probability:.5f}\n"
                )

print("\nResults have been saved to output.txt")

# Note:
# All observed bigrams are printed first. Unseen bigrams (count = 0) are printed afterwards to demonstrate that Laplace (Add-One) smoothing assigns them a non-zero probability.