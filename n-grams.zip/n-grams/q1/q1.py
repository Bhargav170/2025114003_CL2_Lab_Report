from collections import defaultdict

# Read the corpus
with open("./corpus.txt", "r") as file:
    sentences = file.read().split("\n")

# Store all unique words and their counts in a set (unique)
all_words = set()
word_count = defaultdict(int)

for sentence in sentences:
    for word in sentence.split():
        all_words.add(word)
        word_count[word] += 1

# Count bigrams
bigrams_count = defaultdict(int)

for sentence in sentences:
    words = sentence.split()
    for i in range(len(words) - 1):
        bigrams_count[(words[i], words[i + 1])] += 1

# Print the results
print(f"{'Word 1':<12}{'Word 2':<12}| {'Count':<8}| Probability")
print("-" * 50)

for word1, word2 in bigrams_count:
    probability = bigrams_count[(word1, word2)] / word_count[word1]
    print(
        f"{word1:<12}{word2:<12}| {bigrams_count[(word1, word2)]:<8}| {probability:.4f}"
    )

# Also write the results to a file
with open("./q1/output.txt", "w") as output:

    output.write(f"{'Word 1':<12}{'Word 2':<12}| {'Count':<8}| Probability\n")
    output.write("-"*50 + "\n")

    for word1, word2 in bigrams_count:
        probability = bigrams_count[(word1, word2)] / word_count[word1]
        output.write(
            f"{word1:<12}{word2:<12}| {bigrams_count[(word1, word2)]:<8}| {probability:.4f}\n"
        )

print("\nOutput has been copied to file 'output.txt'." )
# The collections.Counter class can also be used to efficiently obtain counts of bigrams