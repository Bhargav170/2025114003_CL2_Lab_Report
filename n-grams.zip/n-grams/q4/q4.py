from collections import defaultdict, Counter

# Read the corpus
with open("./corpus.txt", "r") as file:
    sentences = file.read().strip().split("\n")

# Store all unique words and their counts
all_words = []
word_count = defaultdict(int)

for sentence in sentences:
    for word in sentence.split():
        if word not in all_words:
            all_words.append(word)
        word_count[word] += 1

# Vocabulary size
V = len(all_words)

# Count bigrams
bigrams_count = defaultdict(int)

for sentence in sentences:
    words = sentence.split()
    for i in range(len(words) - 1):
        bigrams_count[(words[i], words[i + 1])] += 1

# Store counts for all possible bigrams
full_counts = {}

for word1 in all_words:
    for word2 in all_words:
        full_counts[(word1, word2)] = bigrams_count.get((word1, word2), 0)

# Total number of observed bigram tokens
N = sum(bigrams_count.values())

# Construct the count-of-counts table
count_of_counts = Counter(full_counts.values())
max_count = max(count_of_counts.keys())

raw = {}

for c in range(max_count + 2):
    raw[c] = count_of_counts.get(c, 0)

print("==============================")
print("RAW COUNT-OF-COUNTS TABLE")
print("==============================\n")

for c in raw:
    print(f"N_{c} = {raw[c]}")

print(
    f"\nGap detected: N_{max_count + 1} = {raw[max_count + 1]} "
    f"(needed for Good-Turing at c = {max_count})"
)
print("Applying Add-One smoothing to the Count-of-Counts table.\n")

# Apply Add-One smoothing to the count-of-counts table
smoothed = {}

for c in range(max_count + 2):
    smoothed[c] = raw[c] + 1

print("==============================")
print("SMOOTHED COUNT-OF-COUNTS TABLE")
print("==============================\n")

for c in smoothed:
    print(f"N_{c}' = {smoothed[c]}")

# Compute Good-Turing discounted counts
c_star = {}

for c in range(max_count + 1):
    c_star[c] = (c + 1) * smoothed[c + 1] / smoothed[c]

print("\n==============================")
print("GOOD-TURING DISCOUNTED COUNTS")
print("==============================\n")

for c in c_star:
    print(f"c = {c}  -->  c* = {c_star[c]:.5f}")

# Sanity check
total_mass = 0

for c in range(max_count + 1):
    total_mass += raw[c] * c_star[c]

total_mass /= N

print("\n==============================")
print("SANITY CHECK")
print("==============================\n")

print(f"Sum(N_c × c*) / N = {total_mass:.5f}")
print("(This value should be close to 1.)")

# Print the complete Good-Turing bigram table
print("\n====================================================================")
print("GOOD-TURING BIGRAM TABLE")
print("====================================================================\n")

print(f"{'Word 1':<12}{'Word 2':<12}| {'Count':<8}| {'c*':<10}| {'P_GT'}")
print("-" * 70)

for word1 in all_words:
    for word2 in all_words:

        count = full_counts[(word1, word2)]
        adjusted_count = c_star[count]
        probability = adjusted_count / N

        print(
            f"{word1:<12}{word2:<12}| {count:<8}| {adjusted_count:<10.5f}| {probability:.6f}"
        )

# Write everything to the output file
with open("./q4/output.txt", "w") as output:

    output.write("==============================\n")
    output.write("RAW COUNT-OF-COUNTS TABLE\n")
    output.write("==============================\n\n")

    for c in raw:
        output.write(f"N_{c} = {raw[c]}\n")

    output.write(
        f"\nGap detected: N_{max_count + 1} = {raw[max_count + 1]} "
        f"(needed for Good-Turing at c = {max_count})\n"
    )
    output.write("Applying Add-One smoothing to the Count-of-Counts table.\n\n")

    output.write("==============================\n")
    output.write("SMOOTHED COUNT-OF-COUNTS TABLE\n")
    output.write("==============================\n\n")

    for c in smoothed:
        output.write(f"N_{c}' = {smoothed[c]}\n")

    output.write("\n==============================\n")
    output.write("GOOD-TURING DISCOUNTED COUNTS\n")
    output.write("==============================\n\n")

    for c in c_star:
        output.write(f"c = {c}  -->  c* = {c_star[c]:.5f}\n")

    output.write("\n==============================\n")
    output.write("SANITY CHECK\n")
    output.write("==============================\n\n")

    output.write(f"Sum(N_c × c*) / N = {total_mass:.5f}\n")
    output.write("(This value should be close to 1.)\n\n")

    output.write("====================================================================\n")
    output.write("GOOD-TURING BIGRAM TABLE\n")
    output.write("====================================================================\n\n")

    output.write(
        f"{'Word 1':<12}{'Word 2':<12}| {'Count':<8}| {'c*':<10}| {'P_GT'}\n"
    )
    output.write("-" * 70 + "\n")

    for word1 in all_words:
        for word2 in all_words:

            count = full_counts[(word1, word2)]
            adjusted_count = c_star[count]
            probability = adjusted_count / N

            output.write(
                f"{word1:<12}{word2:<12}| {count:<8}| {adjusted_count:<10.5f}| {probability:.6f}\n"
            )

print("\nResults have been saved to output.txt")