from collections import defaultdict, Counter

# Read the corpus
with open("./corpus.txt", "r") as file:
    sentences = file.read().strip().split("\n")

# Store all unique words
all_words = []

for sentence in sentences:
    for word in sentence.split():
        if word not in all_words:
            all_words.append(word)

# Count bigrams
bigrams_count = defaultdict(int)

for sentence in sentences:
    words = sentence.split()
    for i in range(len(words) - 1):
        bigrams_count[(words[i], words[i + 1])] += 1

# Total number of observed bigrams
N = sum(bigrams_count.values())

# Count-of-counts table
full_counts = {}

for word1 in all_words:
    for word2 in all_words:
        full_counts[(word1, word2)] = bigrams_count.get((word1, word2), 0)

count_of_counts = Counter(full_counts.values())
max_count = max(count_of_counts)

# Add-one smoothing on count-of-counts
raw = {}
smoothed = {}

for c in range(max_count + 2):
    raw[c] = count_of_counts.get(c, 0)
    smoothed[c] = raw[c] + 1

# Good-Turing discounted count for c = 0
c_star_0 = smoothed[1] / smoothed[0]

# Probability of a missing bigram
p_missing = c_star_0 / N

print("==============================")
print("PROBABILITY OF A MISSING BIGRAM")
print("==============================\n")

print(f"Good-Turing count (c*_0) = {c_star_0:.5f}")
print(f"P(Missing Bigram) = {p_missing:.6f}")

# Write the result to the output file
with open("./q5/output.txt", "w") as output:
    output.write("==============================\n")
    output.write("PROBABILITY OF A MISSING BIGRAM\n")
    output.write("==============================\n\n")
    output.write(f"Good-Turing count (c*_0) = {c_star_0:.5f}\n")
    output.write(f"P(Missing Bigram) = {p_missing:.6f}\n")

print("\nResults have been saved in output.txt")