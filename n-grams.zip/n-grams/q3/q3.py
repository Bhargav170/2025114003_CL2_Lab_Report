# Fixed a small mistake in last line of poem.txt (where s -> where's)

from collections import defaultdict

# Read the corpus
with open("./corpus.txt", "r") as file:
    sentences = file.read().split("\n")

# Store all unique words and their counts
all_words = []
word_count = defaultdict(int)

for sentence in sentences:
    for word in sentence.split():
        if word not in all_words:
            all_words.append(word)
        word_count[word] += 1

# Vocabulary size
V = len(all_words)

# Count bigrams
bigrams_count = defaultdict(int)

for sentence in sentences:
    words = sentence.split()
    for i in range(len(words) - 1):
        bigrams_count[(words[i], words[i + 1])] += 1

# Count the frequency of bigram frequencies
frequency_count = defaultdict(int)

for bigram in bigrams_count:
    frequency_count[bigrams_count[bigram]] += 1

# Print the results
print(f"{'Bigram Frequency':<20}{'Number of Bigrams'}")
print("-" * 40)

for frequency in sorted(frequency_count):
    print(f"{frequency:<20}{frequency_count[frequency]}")

# Write the results to a file
with open("./q3/output.txt", "w") as output:

    output.write(f"{'Bigram Frequency':<20}{'Number of Bigrams'}\n")
    output.write("-" * 40 + "\n")

    for frequency in sorted(frequency_count):
        output.write(f"{frequency:<20}{frequency_count[frequency]}\n")

print("\nResults have been saved to output.txt")